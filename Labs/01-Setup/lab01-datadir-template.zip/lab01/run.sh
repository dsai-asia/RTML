#!/bin/bash

NAME=matt-lab1
SSH_PORT=2224

cd "`dirname $0`"
cd image
docker build . -t $NAME
cd ..
docker run -d -p ${SSH_PORT}:22 -v $HOME/lab01/root:/root --name $NAME $NAME

